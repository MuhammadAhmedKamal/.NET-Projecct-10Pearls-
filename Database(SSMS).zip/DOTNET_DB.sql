


IF NOT EXISTS (SELECT  * FROM SYS.TABLES T WHERE T.NAME = 'REGISTRATION')
BEGIN

CREATE TABLE Registration (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(100), 
    LastName VARCHAR(100),
    Email VARCHAR(100), 
    Password VARCHAR(100),
    IsActive INT
);
END

SELECT * FROM Registration;



IF NOT EXISTS (SELECT  * FROM SYS.TABLES T WHERE T.NAME = 'EmployeeTasks')
BEGIN
CREATE TABLE EmployeeTasks (
	ID INT IDENTITY(1,1) PRIMARY KEY,
	Tasks VARCHAR(100),
	tasksDescription VARCHAR(100),
)
END

SELECT * FROM EmployeeTasks;






