import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Signuppage from './components/Signuppage';
import Loginpage from './components/Loginpage';
import Homepage from './components/Homepage';

function App() {
  return (
    <>
    {/* <Signuppage />
    <Loginpage /> */}

<Router>
      <Routes>
        {/* Set SignUpPage as the home page */}
        <Route path="/" element={<Signuppage />} />
        {/* Route for LoginPage */}
        <Route path="/loginpage" element={<Loginpage />} />
        {/* Route path for HomePage */}
        <Route path='/homepage' element={<Homepage />}/>
      </Routes>
    </Router>


    </>
  );
}

export default App;
