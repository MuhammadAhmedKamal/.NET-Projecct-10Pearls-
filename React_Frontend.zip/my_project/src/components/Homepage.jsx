// import React ,{useState, useEffect}from 'react'
// import './Homepage.css';
// import Table from 'react-bootstrap/Table';
// import Button from 'react-bootstrap/Button';
// import Modal from 'react-bootstrap/Modal';
// import Row from 'react-bootstrap/Row';
// import Col from 'react-bootstrap/Col';
// import Container from 'react-bootstrap/Container';
// import axios from 'axios';

// function Homepage() {
//   function refreshPage()
//   {
//     window.location.reload(false);
//   }
//   const emptasks = [
//                 {
//                     id : 1,
//                     Tasks : " set Alarm",
//                     Description : "Set an alarm for 8 am"
//                 },
//                 {
//                     id : 2,
//                     Tasks : "Morning meeting",
//                     Description : "Attend at 9 am"
//                 }
//             ]
//             const [data, setData] = useState([]);
            
//             useEffect(()=>{
//               getData();
//             },[]) 

//             const getData =() =>
//             {
//               axios.get('https://localhost:7224/api/EmployeeTasks')
//               .then((result)=>{
//                 setData(result.data)
//               })
//               .catch((error)=>{
//                 console.log(error)
//               })
//             }


//             const handleEdit = (id) => {
//                 // alert(id);
//                 handleShow();
//             }

//             const handleDelete = (id) => {
//                 if(window.confirm("Are you sure to delete this tasks") == true)
//                 {
//                     alert(id);
//                 }
//             }

//             const [show, setShow] = useState(false);

//             const handleClose = () => setShow(false);
//             const handleShow = () => setShow(true);

//             const [Task, setTask] = useState('')
//             const [Description, setDescription] = useState('')

//             const[editId,setEditId] = useState('')
//             const [EditTask, setEditTask] = useState('')
//             const [EditDescription, setEditDescription] = useState('')

//             const handleupdate=() => {

//             }


//     return (
//     <>
//         <div className="navbarcontainer">
//             <div className="websitename">
//                 <p onClick={refreshPage}>10 Pearls</p>
//             </div>
//         </div>
//         <div className="userinfo">
//             <div className="welcomenote">
//                 <p>Welcome!</p>
//             </div>
//             <div className="discription">
//                 helloo...its really good to see you again!
//             </div>
//         </div>

//             <br />
//             <br />
            
//             <Container>
//                 <Row>
//                     <Col>
//                     <input type="text" className='form-control' placeholder='Enter Task Name' value={Task} onChange={(e)=> setTask(e.target.value)} />
//                     </Col>
//                     <Col>
//                     <input type="textarea" className='form-control' placeholder='Enter Description' value={Description} onChange={(e)=> setDescription(e.target.value)}/>
//                     </Col>
//                     <Col>
//                     <button className='btn btn-primary'>Submit</button>
//                     </Col>
//                 </Row>
//             </Container>

//             <br />
//             <br />
//         <Table striped bordered hover>
//         <thead>
//         <tr>
//           <th>#</th>
//           <th>Tasks</th>
//           <th>Description</th>
//           <th>Actions</th>
//         </tr>
//       </thead>
//       <tbody>
//         {
//             data && data.length > 0 ?
//             data.map((item,index)=>{
//                 return (
//                     <tr key={index}>
//                         <td>{index+1}</td>  
//                         <td>{item.Tasks}</td>
//                         <td>{item.Description}</td>
//                         <td colSpan={2}>
//                             <button className='btn btn-primary' onClick={()=> handleEdit(item.id)}>Edit</button>
//                             &nbsp;
//                             <button className='btn btn-danger' onClick={()=> handleDelete(item.id)}>Delete</button>
//                         </td>
//                     </tr>
//                 )
//             })
//             :
//             'Loading...'
//         }
//       </tbody>
//     </Table>
//     <Modal show={show} onHide={handleClose} className='model'>
//         <Modal.Header closeButton>
//           <Modal.Title>Edit / Update </Modal.Title>
//         </Modal.Header>

//         <Modal.Body>
//         <Row>
//                     <Col>
//                     <input type="text" className='form-control' placeholder='Enter Task Name' 
//                     value={EditTask} onChange={(e) => setEditTask(e.target.value)}/>
//                     </Col>
//                     <Col>
//                     <input type="textarea" className='form-control' placeholder='Enter Description' 
//                     value={EditDescription} onChange={(e) => setEditDescription(e.target.value)}/>
//                     </Col>
//                 </Row>
//         </Modal.Body>


//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleClose}>
//             Close
//           </Button>
//           <Button variant="primary" onClick={handleupdate}>
//             Save Changes
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </>
//   )
// }

// export default Homepage


// import React, { useState, useEffect } from 'react';
// import './Homepage.css';
// import Table from 'react-bootstrap/Table';
// import Button from 'react-bootstrap/Button';
// import Modal from 'react-bootstrap/Modal';
// import Row from 'react-bootstrap/Row';
// import Col from 'react-bootstrap/Col';
// import Container from 'react-bootstrap/Container';
// import axios from 'axios';

// function Homepage() {
//   const [data, setData] = useState([]);
//   const [Task, setTask] = useState('');
//   const [Description, setDescription] = useState('');
//   const [show, setShow] = useState(false);
//   const [editId, setEditId] = useState('');
//   const [EditTask, setEditTask] = useState('');
//   const [EditDescription, setEditDescription] = useState('');

//   useEffect(() => {
//     getData();
//   }, []);

//   const getData = () => {
//     axios.get('https://localhost:7224/api/EmployeeTasks')
//       .then((result) => setData(result.data))
//       .catch((error) => console.log(error));
//   };

//   const handleSubmit = () => {
//     const newTask = { Tasks: Task, Description: Description };
//     axios.post('https://localhost:7224/api/EmployeeTasks', newTask)
//       .then(() => {
//         getData();
//         setTask('');
//         setDescription('');
//       })
//       .catch((error) => console.log(error));
//   };

//   const handleEdit = (id) => {
//     const task = data.find((item) => item.id === id);
//     if (task) {
//       setEditId(id);
//       setEditTask(task.Tasks);
//       setEditDescription(task.Description);
//       handleShow();
//     }
//   };

//   const handleupdate = () => {
//     const updatedTask = { id: editId, Tasks: EditTask, Description: EditDescription };
//     axios.put(`https://localhost:7224/api/EmployeeTasks/${editId}`, updatedTask)
//       .then(() => {
//         getData();
//         handleClose();
//       })
//       .catch((error) => console.log(error));
//   };

//   const handleDelete = (id) => {
//     if (window.confirm("Are you sure you want to delete this task?")) {
//       axios.delete(`https://localhost:7224/api/EmployeeTasks/${id}`)
//         .then(() => getData())
//         .catch((error) => console.log(error));
//     }
//   };

//   const handleClose = () => setShow(false);
//   const handleShow = () => setShow(true);

//   return (
//     <>
//       <div className="navbarcontainer">
//         <div className="websitename">
//           <p onClick={() => window.location.reload(false)}>10 Pearls</p>
//         </div>
//       </div>
//       <div className="userinfo">
//         <div className="welcomenote"><p>Welcome!</p></div>
//         <div className="discription">Hello... it's really good to see you again!</div>
//       </div>

//       <br />
//       <Container>
//         <Row>
//           <Col>
//             <input type="text" className='form-control' placeholder='Enter Task Name' value={Task} onChange={(e) => setTask(e.target.value)} />
//           </Col>
//           <Col>
//             <input type="textarea" className='form-control' placeholder='Enter Description' value={Description} onChange={(e) => setDescription(e.target.value)} />
//           </Col>
//           <Col>
//             <button className='btn btn-primary' onClick={handleSubmit}>Submit</button>
//           </Col>
//         </Row>
//       </Container>

//       <br />
//       <Table striped bordered hover>
//         <thead>
//           <tr>
//             <th>#</th>
//             <th>Tasks</th>
//             <th>Description</th>
//             <th>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {data && data.length > 0 ? data.map((item, index) => (
//             <tr key={index}>
//               <td>{index + 1}</td>
//               <td>{item.Tasks}</td>
//               <td>{item.Description}</td>
//               <td>
//                 <button className='btn btn-primary' onClick={() => handleEdit(item.id)}>Edit</button>
//                 &nbsp;
//                 <button className='btn btn-danger' onClick={() => handleDelete(item.id)}>Delete</button>
//               </td>
//             </tr>
//           )) : 'Loading...'}
//         </tbody>
//       </Table>

//       <Modal show={show} onHide={handleClose} className='model'>
//         <Modal.Header closeButton><Modal.Title>Edit / Update</Modal.Title></Modal.Header>
//         <Modal.Body>
//           <Row>
//             <Col>
//               <input type="text" className='form-control' placeholder='Enter Task Name' value={EditTask} onChange={(e) => setEditTask(e.target.value)} />
//             </Col>
//             <Col>
//               <input type="textarea" className='form-control' placeholder='Enter Description' value={EditDescription} onChange={(e) => setEditDescription(e.target.value)} />
//             </Col>
//           </Row>
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleClose}>Close</Button>
//           <Button variant="primary" onClick={handleupdate}>Save Changes</Button>
//         </Modal.Footer>
//       </Modal>
//     </>
//   );
// }

// export default Homepage;




import React, { useState, useEffect } from 'react';
import './Homepage.css';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';

function Homepage() {
  // State for tasks data
  const [data, setData] = useState([]);
  
  // State for creating a new task
  const [task, setTask] = useState('');
  const [description, setDescription] = useState('');
  
  // State for editing a task
  const [editId, setEditId] = useState('');
  const [editTask, setEditTask] = useState('');
  const [editDescription, setEditDescription] = useState('');
  
  // Modal visibility state
  const [show, setShow] = useState(false);

  // Fetch tasks from API
  useEffect(() => {
    getData();
  }, []);

  const getData = () => {
    axios.get('https://localhost:7224/api/EmployeeTasks')
      .then((result) => {
        setData(result.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // Function to create a new task
  const handleSubmit = () => {
    const newTask = { Tasks: task, Description: description };
    
    axios.post('https://localhost:7224/api/EmployeeTasks', newTask)
      .then(() => {
        getData();        // Refresh task list
        setTask('');      // Clear input fields
        setDescription('');
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // Function to open edit modal and set task details
  const handleEdit = (id) => {
    const selectedTask = data.find((item) => item.id === id);
    if (selectedTask) {
      setEditId(id);
      setEditTask(selectedTask.Tasks);
      setEditDescription(selectedTask.Description);
      setShow(true);
    }
  };

  // Function to update a task
  const handleUpdate = () => {
    const updatedTask = { id: editId, Tasks: editTask, Description: editDescription };
    
    axios.put(`https://localhost:7224/api/EmployeeTasks/${editId}`, updatedTask)
      .then(() => {
        getData();  // Refresh task list
        handleClose(); // Close the modal
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // Function to delete a task
  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this task?")) {
      axios.delete(`https://localhost:7224/api/EmployeeTasks/${id}`)
        .then(() => {
          getData(); // Refresh task list after deletion
        })
        .catch((error) => {
          console.log(error);
        });
    }
  };

  // Modal control functions
  const handleClose = () => setShow(false);

  return (
    <>
      <div className="navbarcontainer">
        <div className="websitename">
          <p onClick={() => window.location.reload(false)}>10 Pearls</p>
        </div>
      </div>

      <div className="userinfo">
        <div className="welcomenote"><p>Welcome!</p></div>
        <div className="discription">Hello... it's really good to see you again!</div>
      </div>

      <br />
      <Container>
        <Row>
          <Col>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Task Name"
              value={task}
              onChange={(e) => setTask(e.target.value)}
            />
          </Col>
          <Col>
            <input
              type="textarea"
              className="form-control"
              placeholder="Enter Description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </Col>
          <Col>
            <button className="btn btn-primary" onClick={handleSubmit}>Submit</button>
          </Col>
        </Row>
      </Container>

      <br />
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>#</th>
            <th>Tasks</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {data && data.length > 0 ? data.map((item, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{item.Tasks}</td>
              <td>{item.Description}</td>
              <td>
                <button className="btn btn-primary" onClick={() => handleEdit(item.id)}>Edit</button>
                &nbsp;
                <button className="btn btn-danger" onClick={() => handleDelete(item.id)}>Delete</button>
              </td>
            </tr>
          )) : <tr><td colSpan="4">Loading...</td></tr>}
        </tbody>
      </Table>

      {/* Edit Task Modal */}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Edit / Update Task</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col>
              <input
                type="text"
                className="form-control"
                placeholder="Enter Task Name"
                value={editTask}
                onChange={(e) => setEditTask(e.target.value)}
              />
            </Col>
            <Col>
              <input
                type="textarea"
                className="form-control"
                placeholder="Enter Description"
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
              />
            </Col>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>Close</Button>
          <Button variant="primary" onClick={handleUpdate}>Save Changes</Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default Homepage;


