﻿namespace Backend_website.Models
{
    public class EmployeeTasks
    {
        public int Id { get; set; }
        public string Tasks { get; set; }
        public string TasksDescription { get; set; }
        public string Taskstatus { get; set; }
    }
}
