﻿
using Backend_website.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Backend_website.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public RegistrationController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        [Route("registration")]
        public IActionResult Register(Registration registration)
        {
            string connectionString = _configuration.GetConnectionString("DBConnection");

            // Use parameterized queries to avoid SQL injection
            string nonQueryCommand = "INSERT INTO Registration (FirstName, LastName, Email, Password, IsActive) " +
                                     "VALUES (@FirstName, @LastName, @Email, @Password, @IsActive)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // Create a SqlCommand object
                    using (SqlCommand command = new SqlCommand(nonQueryCommand, connection))
                    {
                        // Add parameters
                        command.Parameters.AddWithValue("@FirstName", registration.FirstName);
                        command.Parameters.AddWithValue("@LastName", registration.LastName);
                        command.Parameters.AddWithValue("@Email", registration.Email);
                        command.Parameters.AddWithValue("@Password", registration.Password);
                        command.Parameters.AddWithValue("@IsActive", registration.IsActive);

                        // Execute the non-query command
                        int rowsAffected = command.ExecuteNonQuery();

                        // Return appropriate response
                        if (rowsAffected > 0)
                        {
                            return Ok("Data Inserted Successfully");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to insert data.");
                        }
                    }
                }
                catch (SqlException ex)
                {
                    return StatusCode(500, $"Internal server error: {ex.Message}");
                }
            }
        }



        [HttpGet]
        [Route("login")]
        public IActionResult Login(string email, string password)
        {
            string connectionString = _configuration.GetConnectionString("DBConnection");

            // Query to check if the user exists with the given email and password
            string query = "SELECT COUNT(1) FROM Registration WHERE Email = @Email AND Password = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Password", password);

                        int userExists = Convert.ToInt32(command.ExecuteScalar());

                        if (userExists > 0)
                        {
                            return Ok("Login Successful");
                        }
                        else
                        {
                            return Unauthorized("Invalid email or password");
                        }
                    }
                }
                catch (SqlException ex)
                {
                    return StatusCode(500, $"Internal server error: {ex.Message}");
                }
            }
        }
    
    
        


    }
}


